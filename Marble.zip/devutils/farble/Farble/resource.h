//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Farble.rc
//
#define IDR_MAINFRAME                   128
#define IDD_MAINDLG                     129
#define IDC_BUTTON_Source               1006
#define IDC_BUTTON2                     1007
#define IDC_BUTTON_Descramble           1007
#define IDC_output                      1014
#define IDC_Input                       1015
#define IDC_RADIO_RXOR                  1016
#define IDC_RADIO_XOR                   1017
#define IDC_RADIO_Encrypt               1018
#define IDC_RADIO_Decrypt               1019
#define IDC_RADIO_Source                1020
#define IDC_RADIO_Manual                1021
#define IDC_RADIO_Descramble            1022
#define IDC_RADIO_Randomize             1023
#define IDC_RADIO_Line                  1024
#define IDC_RADIO_Macro                 1025
#define IDC_RADIO_Function              1026
#define IDC_XOR_VAL                     1027
#define IDC_type                        1028
#define IDC_BUTTON_RANDOMIZE            1033
#define IDC_BUTTON_CLEAR                1034
#define IDC_CHECK_BYTE                  1036

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1037
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
