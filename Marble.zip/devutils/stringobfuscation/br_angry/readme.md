# String Obfuscation

Currently used by mdb/droid projects

Usage:

    python create_str.py proj_strings.h <project_name>
