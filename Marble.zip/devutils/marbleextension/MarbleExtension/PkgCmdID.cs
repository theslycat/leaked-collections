﻿// PkgCmdID.cs
// MUST match PkgCmdID.h
using System;

namespace None.MarbleExtension
{
    static class PkgCmdIDList
    {
        public const uint cmdidMarbleBuild =        0x100;
        public const uint cmdidMarbleRebuild =      0x101;
        public const uint cmdidMarbleClean =        0x102;




    };
}